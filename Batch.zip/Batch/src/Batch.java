import java.sql.Connection;
import java.sql.Statement;

public class Batch {
	public static void main(String arg[]) throws Exception{
		Connection con=null;
		int i=0;
		Statement pst = null;
		try {
			 con = Connect.dbcon();
			 pst = con.createStatement();
			 con.setAutoCommit(false);
			 System.out.println("test 1");
			 String SQL = "INSERT INTO Emp (id, first) " +
		             "VALUES(200,'Zia')";
			 pst.addBatch(SQL);
			 String SQL1 = "INSERT INTO Emp (id, first) " +
		             "VALUES(201,'Raj')";
		pst.addBatch(SQL1);
		String SQL2 = "UPDATE Emp SET first = 'a' " +
		             "WHERE id = 100";
		pst.addBatch(SQL2);
		int[] count = pst.executeBatch();
		if(i!= 0) {
			 System.out.println("Test 3");
			 i=0;
			 String SQL3 = "INSERT INTO Emp (id, first) " +
		             "VALUES(201,'Raj')";
				pst.addBatch(SQL3);
			 if(i ==0) {
				 con.rollback();
				 System.out.println("test 4");
			 }
		}
		System.out.println("test 5");
		 con.commit();

}
		catch (Exception e) {
			System.out.println("test 6");
			e.printStackTrace();
		}
		finally {
			System.out.println("test 7");
			con.close();
		}
}
	}